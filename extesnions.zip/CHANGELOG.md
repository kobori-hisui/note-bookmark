# Changelog

## [0.3.1] - 2026-11-16

### Agregado (subcarpetas manuales)
- **Carpetas anidadas con `/`.** `/notes-init/case-use texto` guarda la nota en `case-use`, dentro de `notes-init` (hasta 5 niveles, 60 caracteres por nivel). Con espacios: `/"mi tesis/cap 1" texto`. El campo `folder` de la nota guarda la ruta completa, por lo que **no hay migración**: lo anterior sigue valiendo como rutas de un nivel.
- **Niveles intermedios automáticos.** Una nota en `a/b/c` hace aparecer también `a` y `a/b`, aunque no tengan notas propias. Siguen siendo calculadas, no guardadas.
- **Una carpeta incluye las notas de sus hijas** (`notes-init` = sus notas + las de `case-use`). El panel muestra «N propias» y la barra de filtros tiene «Incluir subcarpetas» para ver solo las directas.
- **Autocompletado de rutas** en el cuadro de nota (`/notes-init/` sugiere sus hijas), en el selector (`Tab`) y en el panel; sin coincidencias se ofrece «Crear».
- **Panel › Carpetas:** vista de árbol con sangría. Renombrar o mover una carpeta arrastra todas sus hijas (`proyectos/tesis` la mueve dentro de `proyectos`) y la carpeta activa sigue el cambio. Quitar una carpeta quita también sus subcarpetas (las notas no se borran). Todo con Deshacer.
- **Popup y sidebar:** las carpetas hijas se pintan dentro de su padre (en el sidebar con sangría y solo su último nivel). En el sidebar cada carpeta con hijas tiene una flecha ▾/▸ para plegarla o desplegarla; se recuerda entre sesiones.

### Agregado (insertar notas en cualquier sitio)
- **Comando `/carpeta` en cualquier campo de texto** (textarea, input y editores `contenteditable`). Al escribir `/blonde-beatiful/biography` aparece una lista con las notas de esa carpeta: `Enter` inserta el texto en el lugar del comando, `Alt+Enter` inserta la cita en vez de la nota, y los botones 🖼 (o `Shift+Enter`) copian la imagen al portapapeles como PNG para pegarla con `Ctrl+V`. Una nota que solo tiene imágenes copia la primera.
- **Rutas parciales:** `/biog` sugiere carpetas (coincide por el inicio de la ruta o de su último nivel); `Tab`/`Enter` completan y abren la lista de notas. Con una carpeta con hijas, las hijas salen primero para bajar un nivel.
- **No estorba a la página:** el menú solo se abre si el `/` va al inicio o tras un espacio, hay al menos 2 caracteres y lo escrito coincide con una carpeta tuya. Ignora campos de contraseña, de solo lectura y el Shadow DOM de otros. Mientras está abierto captura ↑ ↓ Enter Tab Esc (así Enter no envía el mensaje del chat); cualquier otra tecla sigue al campo.
- **Ajustes › Insertar notas en cualquier sitio:** para apagarlo.
- Archivo nuevo: `entrypoints/content/inline-insert.ts`. Las notas se leen del storage solo la primera vez que se abre el menú y se sueltan de memoria a los 60 s.

### Limitaciones conocidas
- El menú del `/carpeta` en campos de texto se ancla al campo (en input/textarea el navegador no da la posición del cursor); en `contenteditable` sale junto al cursor. No funciona dentro de iframes ni de Shadow DOM de la página.
- Algunos editores ignoran `execCommand('insertText')`; en ese caso se usa un respaldo que inserta el nodo de texto.
- Una nota que empiece con una ruta (`/usr/bin ...`) ahora se interpreta como comando de carpeta. Para escribirla tal cual, antepón un espacio o un carácter.
- Las carpetas manuales que ya tuvieran una `/` en el nombre (creadas con comillas) pasan a ser anidadas.
- Las estadísticas cuentan solo notas propias de cada carpeta, para que un padre no repita las de sus hijas.

### Archivos modificados
`utils/folders.ts` (árbol, `cleanFolderPath`, `rebasePath`), `utils/bookmarks.ts`, `utils/backup.ts`, `entrypoints/content/index.ts`, `entrypoints/popup/main.ts`, `dashboard/store/bookmarks.tsx`, `dashboard/lib/{actions,search,stats,backupIO}.ts`, `dashboard/pages/{FoldersPage,NotesPage}.tsx`, `dashboard/components/layout/Sidebar.tsx`, `dashboard/style.css`, `dashboard/pages/SettingsPage.tsx`, `utils/settings.ts`, `dashboard/components/notes/{FolderPicker,NoteDrawer,NotesToolbar}.tsx`, `dashboard/components/ui/PromptModal.tsx`, `README.md`, `package.json`

## [0.3.0] - 2026-11-12

### Agregado (panel de administración)
- **Panel completo en una pestaña** (`entrypoints/dashboard/`, React + TypeScript), pensado para trabajar con muchas notas. Se abre desde el popup y se publica como `/dashboard.html`. El popup se mantiene como acceso rápido.
- **Notas:** vista de tabla o cuadrícula (se recuerda la elección), búsqueda global en notas, citas, títulos, URLs y carpetas (atajo `/`), filtros por carpeta, fecha e imágenes, y orden (recientes, antiguas, por sitio). Carga por tandas de 60 con «Mostrar más».
- **Acciones en lote:** selección múltiple (Shift+clic para rangos) para mover a carpeta, fusionar, exportar la selección o borrar. Todas con aviso y **Deshacer**.
- **Panel de detalle** de cada nota: imágenes con visor, cita y edición de título, texto, URL y carpeta, además de abrir y ubicar la nota en su página.
- **Carpetas:** listado con tipo (manual / automática), cantidad de notas y última nota. Renombrar (si el nombre ya existe, se fusionan) y quitar carpetas manuales; sus notas vuelven al agrupado automático. La carpeta activa sigue el cambio de nombre.
- **Estadísticas:** notas, carpetas, sitios, notas con imágenes, espacio usado, notas por día (30 días) y rankings de sitios y carpetas.
- **Datos:** exportar JSON o `.db` e importar JSON (suma sin pisar nada).
- **Ajustes:** modo de imágenes, descarga masiva con progreso, liberar espacio y carpeta activa.
- **Estructura modular para escalar:** una sección nueva = `pages/Nueva.tsx` + una línea en `routes.tsx`; filtros en `lib/search.ts`; acciones con deshacer en `lib/useActions.ts`; componentes base en `components/ui/`; estado en `store/`. Toda la lógica de datos está en `lib/` sin React. Reutiliza `utils/` tal cual, sin duplicar código.
- Dependencias nuevas: `react`, `react-dom`, `@wxt-dev/module-react`. Sin librerías de gráficos ni de rutas (CSS puro y router por hash).

### Agregado (autocompletado de carpeta)
- **Sugerencias al escribir `/carpeta`** en el cuadro de nota (antes solo existía el selector con `Tab`). Al escribir `/` o `/sis…` al inicio aparece la lista de carpetas que coinciden; ↑ ↓ eligen y `Tab` o `Enter` completan (`/sisters-friends `, o `/"mi tesis" ` si lleva espacios). Sin coincidencias no aparece nada y `Enter` guarda normal, así que crear una carpeta nueva sigue igual.

### Limitaciones conocidas
- Las sugerencias solo listan carpetas **manuales** que tengan alguna nota o sean la carpeta activa. Una carpeta recién creada sin notas aparece solo mientras sea la activa.
- La tabla de notas usa «Mostrar más» en vez de virtualización; con decenas de miles de notas conviene migrar el almacenamiento a IndexedDB.

### Archivos modificados
`entrypoints/content/index.ts` (autocompletado), `entrypoints/popup/main.ts` (botón al panel), `wxt.config.ts` (`modules: ['@wxt-dev/module-react']`, fuera de `manifest`), `tsconfig.json` (`jsx: react-jsx`), `package.json`
**Nuevo:** `entrypoints/dashboard/` (`index.html`, `main.tsx`, `App.tsx`, `routes.tsx`, `style.css`, `pages/`, `components/`, `lib/`, `store/`)

## [0.2.0] - 2026-11-12

### Agregado
- **Guardar imágenes como nota.** El menú contextual ahora aparece también al hacer clic derecho sobre una imagen (antes solo con texto seleccionado). El ítem pasó a llamarse "Guardar como nota".
- **Varias imágenes a la vez.** Si seleccionas un rango con imágenes y haces clic derecho, se adjuntan todas las que están completamente dentro de la selección (máx. 30). También funciona con `Alt+C` si hay una selección con imágenes.
- **Miniaturas en el cuadro de nota** con botón ✕ para quitar las que no quieras, indicador de descarga ("Descargando N…") y contador ("N imágenes"). Se puede guardar con solo imágenes, sin texto ni cita.
- **Descarga desde el background** (`fetch-image`): usa `host_permissions`, así evita CORS. Soporta URLs `http(s)`, `data:` y `blob:`.
- **Reducción automática:** las imágenes se guardan como JPEG de máx. 1600 px de ancho (calidad 0.85, fondo blanco para transparencias) para no inflar el storage.
- **Galería en el historial:** las notas muestran una cuadrícula con sus imágenes.
- **Visor de imágenes dentro del popup:** al hacer clic en una imagen se abre en grande, con navegación ‹ › / ← →, contador, y cierre con Esc, ✕ o clic fuera. También se usa para la captura de región.
- **Alt+S:** la lista de notas de la página indica cuántas imágenes tiene cada nota (🖼 N).
- **Exportar a SQLite:** nueva tabla `bookmark_images (bookmark_id, position, image BLOB, image_mime)`; `PRAGMA user_version` sube a 2.

### Agregado (ubicar la nota en la página)
- **Ubicación propia, sin depender de Chrome.** Al abrir una nota desde el historial, la pestaña se desplaza hasta el texto o la imagen guardados y los marca con un recuadro amarillo/rojo y un aviso. El texto se busca en el DOM ignorando espacios y bloques (funciona con etiquetas `inline-block`/`flex`, como en nhentai.net); si se repite, elige la aparición más cercana a la posición guardada; las imágenes se encuentran por su URL original (incluye `data-src`/`srcset`); si no aparece nada, deja en la zona aproximada donde se guardó. Reintenta ~12 s por si la página carga contenido después.
- **Alt+S:** hacer clic en una nota de la lista lleva a su lugar en la página actual.
- Campos nuevos opcionales en la nota: `imageSrcs` (URL original de cada imagen) y `anchor` (posición en la página). `fragment` queda como respaldo para Ctrl/Shift/clic central sobre el enlace.
- Archivo nuevo: `locate.ts` (junto al content script).

### Corregido (imágenes al ubicar la nota)
- Las imágenes ahora se encuentran aunque el sitio cambie de subdominio de CDN (t1/t3/t5…), de formato (`.jpg` / `.jpg.webp`) o de parámetros entre cargas: se comparan por varias claves (host+ruta, ruta, carpeta/archivo sin extensión).
- Si la imagen aún no tiene tamaño (carga perezosa), el marcador usa su contenedor visible; y la vista se reajusta tras unos segundos si el layout se movió.

### Agregado (ajustes de imágenes)
- **Panel de Ajustes (⚙)** en el historial con dos modos para las imágenes de las notas:
  - **Solo enlace (por defecto):** se guarda únicamente la URL de la imagen. Casi no ocupa espacio y el historial sigue rápido con miles de notas. Necesita internet y que el sitio no borre la imagen.
  - **Descargar (offline):** se guarda la imagen dentro de la extensión (comportamiento anterior).
- **Descargar ahora las imágenes de mis notas:** convierte los enlaces en copias offline (4 en paralelo, se guarda por tandas, muestra el progreso).
- **Liberar espacio:** borra las copias descargadas y deja solo los enlaces (si la nota conoce la URL original).
- Contador de uso: nº de notas, imágenes descargadas / solo enlace y espacio aproximado.
- `images` de una nota puede contener URLs http(s) además de dataURLs. Si una imagen remota no carga (sin internet, borrada o con anti-hotlink) el historial muestra "🖼 no disponible".
- Exportar a SQLite: `bookmark_images.image` / `image_mime` pueden ser NULL y hay una columna nueva `source_url`.
- Archivo nuevo: `settings.ts` (en `utils/`).

### Agregado (carpetas manuales)
- **Atajo de carpeta en el cuadro de nota:** `Tab` (o el botón 📁) abre un selector para elegir una carpeta existente o crear una nueva escribiendo su nombre (↑ ↓ navegan, Enter elige, Esc cierra).
- **Carpeta activa:** la elegida se conserva (también entre pestañas) y todas las notas nuevas se guardan en ella hasta que la cambies o elijas "Sin carpeta fija". El botón muestra su nombre.
- **Comando `/carpeta` dentro de la nota:** escribir `/news texto` al inicio guarda esa nota en la carpeta «news» (se crea si no existe) sin cambiar la carpeta activa; `/"mi tesis" texto` para nombres con espacios; solo `/news` + Enter cambia la carpeta activa. El botón 📁 muestra el destino mientras escribes. También funciona con el botón Región. Las notas sin comando siguen el flujo normal.
- Las carpetas manuales aparecen en el historial con 🗂️, mandan sobre el agrupado automático (aunque tengan una sola nota) y conservan las subcarpetas por página. "Tesis" y "tesis" son la misma carpeta.
- Al editar una nota en el historial se puede cambiar su carpeta (vacío = automática).
- Campo nuevo opcional `folder` en la nota (se exporta/importa y se junta al fusionar). El `.db` usa el nombre de la carpeta manual en la columna `folder`.

### Cambiado
- **Enlace a la cita (text fragment):** ahora el fragmento se calcula al seleccionar, partiendo el texto por bloques de la página, y se guarda en el nuevo campo opcional `fragment`. Usa la forma `inicio,fin`, así la cita se resalta aunque cruce varios bloques (etiquetas `inline-block`/`flex`, como en nhentai.net). Las notas viejas siguen usando el método anterior.
- Modelo `Bookmark`: nuevo campo opcional `images?: string[] | null`. Las notas anteriores siguen funcionando sin migración.
- Fusionar notas ahora junta también las imágenes de todas las partes.
- Importar JSON valida y conserva `images` (solo `data:image/...`).
- La validación de "nota vacía" al editar considera las imágenes.
- El botón "Región" conserva las imágenes ya adjuntas al guardar.

### Corregido
- Al seleccionar 3 imágenes se adjuntaban 4 (se colaba la imagen vecina que solo rozaba el borde de la selección). Ahora solo se toman las completamente contenidas; la imagen donde se hace clic derecho siempre se incluye.

### Limitaciones conocidas
- Sitios con protección anti-hotlink (revisan el Referer) pueden responder 403: esas imágenes no se descargan y se avisa con "N sin descargar".
- Las imágenes SVG no se pueden convertir y se omiten.
- Las imágenes dentro de Shadow DOM no se detectan en la selección múltiple (el clic derecho directo sí funciona).

### Archivos modificados
`background.ts`, `index.ts` (content script), `bookmarks.ts`, `backup.ts`, `sqlite.ts`, `main.ts`, `style.css`, `quote.ts`, `index.html`, `folders.ts`, `locate.ts` (nuevo, en el content script)
**Nuevo:** `utils/image.ts`